# site-cha-e-encantos
Site desenvolvido para o projeto acadêmico Chá &amp; Encantos, uma loja temática de chás, com proposta sensorial, naturalista e acolhedora.
